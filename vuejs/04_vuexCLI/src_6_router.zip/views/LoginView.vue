<template>
  <div>
    <h1>Login</h1>
    <HappyWorld />
  </div>
</template>
<script>
import HappyWorld from "@/components/HappyWorld.vue";
export default {
  name: "LoginView",
  components: {
    HappyWorld,
  },
};
</script>