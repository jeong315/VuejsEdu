<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png" />
    <HappyWorld />
    <HappyWorld2 />
  </div>
</template>

<script>
import HappyWorld from "./components/HappyWorld.vue";
import HappyWorld2 from "./components/HappyWorld2.vue";

export default {
  name: "App",
  components: {
    HappyWorld,
    HappyWorld2,
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
