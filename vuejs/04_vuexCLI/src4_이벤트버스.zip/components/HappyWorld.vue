<template>
  <div>
    <h1>HappyWorld</h1>
    <button @click="send">Happy2 요청</button>
  </div>
</template>
<script>
import eventBus from "./EventBus.vue";

export default {
  name: "HappyWorld",
  methods: {
    send() {
      eventBus.$emit("xyz", "홍길동");
    },
  },
};
</script>
<style>
h1 {
  color: red;
}
</style>