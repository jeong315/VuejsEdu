<template>
  <div>
    <h1>HappyWorld2</h1>
  </div>
</template>
<script>
import eventBus from "./EventBus.vue";

export default {
  name: "HappyWorld2",
  created() {
    eventBus.$on("xyz", this.receive);
  },
  methods: {
    receive(name) {
      console.log("receive", name);
    },
  },
};
</script>
<style>
h1 {
  color: red;
}
</style>