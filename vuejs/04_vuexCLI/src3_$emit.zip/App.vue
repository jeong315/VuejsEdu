<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png" />
    <HappyWorld v-on:xyz="receive" />
  </div>
</template>
<script>
import HappyWorld from "./components/HappyWorld.vue";

export default {
  name: "App",
  components: {
    HappyWorld,
  },
  methods: {
    receive() {
      console.log("receive");
    },
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
