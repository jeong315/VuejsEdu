<template>
  <div>
    <h1>HappyWorld</h1>
    <button @click="send">부모요청</button>
  </div>
</template>
<script>
export default {
  name: "HappyWorld",
  methods: {
    send() {
      this.$emit("xyz");
    },
  },
};
</script>
<style>
h1 {
  color: red;
}
</style>