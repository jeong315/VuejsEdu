import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    username: "",
  },
  getters: {},
  mutations: {
    mutataion_trans(state, payload) {
      console.log("mutations.mutataion_trans");
      state.username = payload.name;
    },
  },
  actions: {},
  modules: {},
});
