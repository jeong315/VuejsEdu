<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png" />
    <HappyWorld
      username="홍길동"
      nums="[10,20,30,40]"
      isMarried="true"
      :addr="address"
    />
  </div>
</template>
<script>
import HappyWorld from "./components/HappyWorld.vue";
export default {
  name: "App",
  components: {
    HappyWorld,
  },
  data: () => {
    return {
      address: "서울",
    };
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
