<template>
  <div>
    <h1>HappyWorld</h1>
    이름:{{ username }}<br />
    nums:{{ nums }}<br />
    isMarried:{{ isMarried }}<br />
    addr:{{ addr }}<br />
    nums 반복<br />
    <ul v-for="(n, idx) in nums" :key="idx">
      <li>{{ n }}</li>
    </ul>
  </div>
</template>
<script>
export default {
  name: "HappyWorld",
  props: ["username", "nums", "isMarried", "addr"],
};
</script>
<style>
h1 {
  color: red;
}
</style>