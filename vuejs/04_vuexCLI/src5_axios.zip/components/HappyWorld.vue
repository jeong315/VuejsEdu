<template>
  <div>
    <h1>HappyWorld</h1>
    <button @click="send">reqres.in</button>
  </div>
</template>
<script>
//npm install axios 하고 코드에서 import
import axios from "axios";

export default {
  name: "HappyWorld",
  methods: {
    send() {
      axios
        .get("https://reqres.in/api/users?page=2") //Spring 인경우 @RequestParam("page")
        .then(function (response) {
          // handle success
          console.log(response.data.data);
        })
        .catch(function (error) {
          // handle error
          console.log(error);
        })
        .then(function () {
          // always executed
        });
    },
  },
};
</script>
<style>
h1 {
  color: red;
}
</style>