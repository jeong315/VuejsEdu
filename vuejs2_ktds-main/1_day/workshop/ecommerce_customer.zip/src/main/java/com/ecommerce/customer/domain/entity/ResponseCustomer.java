package com.ecommerce.customer.domain.entity;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

public class ResponseCustomer implements Serializable{

	private String userid;
	private String pwd;
	private String name;

	
	public ResponseCustomer() {
	}

	public ResponseCustomer(String userid, String pwd, String name) {
		this.userid = userid;
		this.pwd = pwd;
		this.name = name;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "ResponseCustomer [userid=" + userid + ", pwd=" + pwd + ", name=" + name + "]";
	}

   
}
